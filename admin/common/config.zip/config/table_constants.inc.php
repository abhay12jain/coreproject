<?php

define('TABLE_ADMIN','admin');
define('TABLE_Obituaries','obituaries');
define('TABLE_Condolence','condolence');
define('TABLE_EMAIL_TEMPLATES','email_templates');
?>

 

